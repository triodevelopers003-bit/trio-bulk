import express from "express";
import { createServer as createViteServer } from "vite";
import db from "./src/db.js";
import dotenv from "dotenv";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- API Routes ---

  // Auth Mock
  app.post("/api/auth/login", (req, res) => {
    const { phone, password } = req.body;
    // Simple mock auth
    res.json({ 
      success: true, 
      token: "mock-jwt-token",
      user: { name: "Admin", role: "admin" }
    });
  });

  // Contacts
  app.get("/api/contacts", (req, res) => {
    const contacts = db.prepare("SELECT c.*, b.name as batch_name FROM contacts c LEFT JOIN batches b ON c.batch_id = b.id").all();
    res.json(contacts);
  });

  app.post("/api/contacts", (req, res) => {
    const { name, phone, batch_id, tag, category, notes } = req.body;
    const info = db.prepare("INSERT INTO contacts (name, phone, batch_id, tag, category, notes) VALUES (?, ?, ?, ?, ?, ?)").run(name, phone, batch_id, tag, category, notes);
    res.json({ id: info.lastInsertRowid });
  });

  // Batches
  app.get("/api/batches", (req, res) => {
    const batches = db.prepare("SELECT * FROM batches").all();
    res.json(batches);
  });

  app.post("/api/batches", (req, res) => {
    const { name, description } = req.body;
    const info = db.prepare("INSERT INTO batches (name, description) VALUES (?, ?)").run(name, description);
    res.json({ id: info.lastInsertRowid });
  });

  // Campaigns
  app.get("/api/campaigns", (req, res) => {
    const campaigns = db.prepare("SELECT * FROM campaigns ORDER BY created_at DESC").all();
    res.json(campaigns);
  });

  app.post("/api/campaigns", (req, res) => {
    const { name, content, type, scheduled_at } = req.body;
    const info = db.prepare("INSERT INTO campaigns (name, content, type, scheduled_at) VALUES (?, ?, ?, ?)").run(name, content, type, scheduled_at);
    res.json({ id: info.lastInsertRowid });
  });

  // Stats
  app.get("/api/stats", (req, res) => {
    const totalContacts = db.prepare("SELECT COUNT(*) as count FROM contacts").get().count;
    const totalCampaigns = db.prepare("SELECT COUNT(*) as count FROM campaigns").get().count;
    const totalMessages = db.prepare("SELECT COUNT(*) as count FROM message_logs").get().count;
    const pendingPayments = db.prepare("SELECT COUNT(*) as count FROM payments WHERE status = 'pending'").get().count;
    
    // Mock trial logic: trial started 2 days ago
    const trialStartedAt = new Date();
    trialStartedAt.setDate(trialStartedAt.getDate() - 2);

    res.json({
      totalContacts,
      totalCampaigns,
      totalMessages,
      pendingPayments,
      trialStartedAt: trialStartedAt.toISOString(),
      recentActivity: [
        { label: "Messages Sent", value: 1240, change: "+12%" },
        { label: "Delivery Rate", value: "98.2%", change: "+0.5%" },
        { label: "Active Campaigns", value: 5, change: "0" }
      ]
    });
  });

  // Settings
  app.get("/api/settings", (req, res) => {
    const settings = db.prepare("SELECT whatsapp_api_key, whatsapp_phone_id, whatsapp_business_id FROM users WHERE id = 1").get();
    res.json(settings || {});
  });

  app.post("/api/settings", (req, res) => {
    const { whatsapp_api_key, whatsapp_phone_id, whatsapp_business_id } = req.body;
    db.prepare("UPDATE users SET whatsapp_api_key = ?, whatsapp_phone_id = ?, whatsapp_business_id = ? WHERE id = 1").run(whatsapp_api_key, whatsapp_phone_id, whatsapp_business_id);
    res.json({ success: true });
  });

  // Notifications
  app.get("/api/notifications", (req, res) => {
    res.json([
      { id: 1, title: "Campaign Completed", message: "Your 'Morning Batch' campaign has finished.", time: "5m ago", read: false },
      { id: 2, title: "New Payment", message: "A new payment of ₹1799 is pending verification.", time: "1h ago", read: false },
      { id: 3, title: "Trial Ending", message: "Your free trial ends in 5 days. Upgrade now!", time: "2h ago", read: true },
    ]);
  });

  // Payments
  app.post("/api/payments", (req, res) => {
    const { plan_name, amount, transaction_id, payment_method } = req.body;
    const info = db.prepare("INSERT INTO payments (plan_name, amount, transaction_id, payment_method) VALUES (?, ?, ?, ?)").run(plan_name, amount, transaction_id, payment_method);
    res.json({ id: info.lastInsertRowid });
  });

  // --- Vite Middleware ---
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static("dist"));
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
