# Database Schema

## Users (Admins/Sub-admins)
- id: INTEGER PRIMARY KEY
- name: TEXT
- email: TEXT UNIQUE
- phone: TEXT UNIQUE
- password_hash: TEXT
- role: TEXT (admin, sub-admin)
- whatsapp_api_key: TEXT
- whatsapp_phone_id: TEXT
- whatsapp_business_id: TEXT
- api_token: TEXT
- status: TEXT (active, inactive)
- created_at: DATETIME

## Students/Contacts
- id: INTEGER PRIMARY KEY
- name: TEXT
- phone: TEXT
- batch_id: INTEGER
- tag: TEXT
- category: TEXT
- notes: TEXT
- created_at: DATETIME

## Batches
- id: INTEGER PRIMARY KEY
- name: TEXT
- description: TEXT
- created_at: DATETIME

## Messages/Campaigns
- id: INTEGER PRIMARY KEY
- name: TEXT
- content: TEXT
- type: TEXT (bulk, scheduled, automated)
- status: TEXT (pending, processing, completed, failed)
- scheduled_at: DATETIME
- created_at: DATETIME

## MessageLogs
- id: INTEGER PRIMARY KEY
- campaign_id: INTEGER
- contact_id: INTEGER
- status: TEXT (sent, delivered, read, failed)
- error_message: TEXT
- sent_at: DATETIME

## Payments
- id: INTEGER PRIMARY KEY
- user_id: INTEGER
- plan_id: INTEGER
- amount: REAL
- transaction_id: TEXT
- status: TEXT (pending, verified, rejected)
- payment_method: TEXT
- created_at: DATETIME

## Plans
- id: INTEGER PRIMARY KEY
- name: TEXT
- price: REAL
- duration_days: INTEGER
- message_limit: INTEGER
- features: TEXT (JSON)
