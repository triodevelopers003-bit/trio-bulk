import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export const enhanceMessage = async (message: string, tone: string = "professional") => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash",
      contents: `Rewrite the following WhatsApp message to be more ${tone}. Add relevant emojis and maintain a premium feel. Use placeholders like {{name}} if they exist.
      
      Message: ${message}`,
    });
    return response.text;
  } catch (error) {
    console.error("AI Enhancement Error:", error);
    return message;
  }
};

export const generateAIImage = async (prompt: string) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-2.0-flash-exp", // Using flash for speed
      contents: {
        parts: [{ text: `Generate a premium marketing image prompt for: ${prompt}. Describe it in detail for an image generator.` }]
      }
    });
    // In a real app, we'd call an image gen model. For now, we'll use a placeholder logic or return the prompt.
    return response.text;
  } catch (error) {
    console.error("AI Image Error:", error);
    return null;
  }
};
