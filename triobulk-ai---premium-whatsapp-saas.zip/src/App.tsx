import React, { useState, useEffect, useRef } from 'react';
import { 
  LayoutDashboard, 
  Users, 
  Layers, 
  Send, 
  History, 
  CreditCard, 
  Settings, 
  Sparkles, 
  LogOut,
  Menu,
  X,
  Bell,
  Search,
  ChevronRight,
  TrendingUp,
  MessageSquare,
  Clock,
  CheckCircle2,
  AlertCircle,
  Plus,
  Upload,
  FileText,
  Smartphone,
  QrCode,
  Copy,
  Check,
  Image as ImageIcon,
  Video,
  File,
  Shield,
  Key,
  Globe,
  Palette,
  Zap,
  Crown
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';
import * as XLSX from 'xlsx';
import { QRCodeSVG } from 'qrcode.react';

// Utility
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Shared Components ---

const Modal = ({ isOpen, onClose, title, children }: any) => (
  <AnimatePresence>
    {isOpen && (
      <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={onClose}
          className="absolute inset-0 bg-black/80 backdrop-blur-sm"
        />
        <motion.div 
          initial={{ opacity: 0, scale: 0.95, y: 20 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.95, y: 20 }}
          className="relative w-full max-w-lg glass-card !p-0 overflow-hidden shadow-2xl border-white/20"
        >
          <div className="p-6 border-b border-white/10 flex justify-between items-center bg-white/5">
            <h3 className="text-xl font-bold">{title}</h3>
            <button onClick={onClose} className="p-2 hover:bg-white/10 rounded-lg transition-colors">
              <X size={20} />
            </button>
          </div>
          <div className="p-6">
            {children}
          </div>
        </motion.div>
      </div>
    )}
  </AnimatePresence>
);

const Toast = ({ message, type = 'success', onClose }: any) => (
  <motion.div 
    initial={{ opacity: 0, x: 100 }}
    animate={{ opacity: 1, x: 0 }}
    exit={{ opacity: 0, x: 100 }}
    className={cn(
      "fixed bottom-8 right-8 z-[200] px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 border",
      type === 'success' ? "bg-emerald-500/10 border-emerald-500/50 text-emerald-400" : "bg-red-500/10 border-red-500/50 text-red-400"
    )}
  >
    {type === 'success' ? <CheckCircle2 size={20} /> : <AlertCircle size={20} />}
    <span className="font-bold">{message}</span>
    <button onClick={onClose} className="ml-4 opacity-50 hover:opacity-100"><X size={16} /></button>
  </motion.div>
);

const SidebarItem = ({ icon: Icon, label, active, onClick }: any) => (
  <button
    onClick={onClick}
    className={cn(
      "w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 group",
      active 
        ? "bg-emerald-500 text-white shadow-lg shadow-emerald-500/20" 
        : "text-zinc-400 hover:bg-white/5 hover:text-white"
    )}
  >
    <Icon size={20} className={cn(active ? "text-white" : "text-zinc-400 group-hover:text-white")} />
    <span className="font-medium">{label}</span>
    {active && <motion.div layoutId="active-pill" className="ml-auto w-1.5 h-1.5 rounded-full bg-white" />}
  </button>
);

const StatCard = ({ label, value, change, icon: Icon, color }: any) => (
  <div className="glass-card flex flex-col gap-4">
    <div className="flex justify-between items-start">
      <div className={cn("p-3 rounded-xl", color)}>
        <Icon size={24} className="text-white" />
      </div>
      <span className={cn("text-xs font-medium px-2 py-1 rounded-full bg-emerald-500/10 text-emerald-400")}>
        {change}
      </span>
    </div>
    <div>
      <p className="text-zinc-400 text-sm font-medium">{label}</p>
      <h3 className="text-3xl font-bold mt-1">{value}</h3>
    </div>
  </div>
);

// --- Views ---

const DashboardView = ({ stats }: any) => (
  <div className="space-y-8">
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      <StatCard label="Total Contacts" value={stats?.totalContacts || 0} change="+12.5%" icon={Users} color="bg-blue-500" />
      <StatCard label="Messages Sent" value={stats?.totalMessages || 0} change="+8.2%" icon={Send} color="bg-emerald-500" />
      <StatCard label="Active Campaigns" value={stats?.totalCampaigns || 0} change="+2" icon={Layers} color="bg-purple-500" />
      <StatCard label="Pending Payments" value={stats?.pendingPayments || 0} change="0" icon={CreditCard} color="bg-amber-500" />
    </div>

    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 glass-card">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold">Campaign Performance</h3>
          <select className="bg-white/5 border border-white/10 rounded-lg px-3 py-1 text-sm outline-none">
            <option>Last 7 Days</option>
            <option>Last 30 Days</option>
          </select>
        </div>
        <div className="h-[300px] flex items-end justify-between gap-2">
          {[40, 70, 45, 90, 65, 85, 55].map((h, i) => (
            <div key={i} className="flex-1 flex flex-col items-center gap-2">
              <motion.div 
                initial={{ height: 0 }}
                animate={{ height: `${h}%` }}
                className="w-full max-w-[40px] bg-gradient-to-t from-emerald-500/20 to-emerald-500 rounded-t-lg"
              />
              <span className="text-[10px] text-zinc-500 uppercase font-bold">Day {i+1}</span>
            </div>
          ))}
        </div>
      </div>

      <div className="glass-card">
        <h3 className="text-xl font-bold mb-6">Recent Activity</h3>
        <div className="space-y-6">
          {[
            { icon: CheckCircle2, text: "Campaign 'Batch A' completed", time: "2 mins ago", color: "text-emerald-400" },
            { icon: Clock, text: "Scheduled 'Weekly Update'", time: "1 hour ago", color: "text-blue-400" },
            { icon: AlertCircle, text: "Payment verification pending", time: "3 hours ago", color: "text-amber-400" },
            { icon: MessageSquare, text: "New template created", time: "5 hours ago", color: "text-purple-400" },
          ].map((item, i) => (
            <div key={i} className="flex gap-4">
              <div className={cn("mt-1", item.color)}>
                <item.icon size={18} />
              </div>
              <div>
                <p className="text-sm font-medium text-zinc-200">{item.text}</p>
                <p className="text-xs text-zinc-500">{item.time}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  </div>
);

const ContactsView = ({ showToast }: any) => {
  const [contacts, setContacts] = useState([]);
  const [batches, setBatches] = useState([]);
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isExcelModalOpen, setIsExcelModalOpen] = useState(false);
  const [newContact, setNewContact] = useState({ name: '', phone: '', batch_id: '', tag: '', category: '', notes: '' });

  const fetchContacts = () => {
    fetch('/api/contacts').then(res => res.json()).then(setContacts);
  };

  useEffect(() => {
    fetchContacts();
    fetch('/api/batches').then(res => res.json()).then(setBatches);
  }, []);

  const handleAddContact = async (e: any) => {
    e.preventDefault();
    const res = await fetch('/api/contacts', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(newContact)
    });
    if (res.ok) {
      showToast("Contact added successfully!");
      setIsAddModalOpen(false);
      setNewContact({ name: '', phone: '', batch_id: '', tag: '', category: '', notes: '' });
      fetchContacts();
    }
  };

  const handleFileUpload = (e: any) => {
    const file = e.target.files[0];
    const reader = new FileReader();
    reader.onload = (evt: any) => {
      const bstr = evt.target.result;
      const wb = XLSX.read(bstr, { type: 'binary' });
      const wsname = wb.SheetNames[0];
      const ws = wb.Sheets[wsname];
      const data = XLSX.utils.sheet_to_json(ws);
      
      // Bulk insert mock logic
      Promise.all(data.map((item: any) => 
        fetch('/api/contacts', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: item.Name || item.name || '',
            phone: item.Phone || item.phone || item.Number || '',
            batch_id: null,
            tag: 'Excel Import'
          })
        })
      )).then(() => {
        showToast(`Successfully imported ${data.length} contacts!`);
        setIsExcelModalOpen(false);
        fetchContacts();
      });
    };
    reader.readAsBinaryString(file);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold">Contacts Management</h2>
          <p className="text-zinc-400">Manage your students and user database</p>
        </div>
        <div className="flex gap-3">
          <button 
            onClick={() => setIsExcelModalOpen(true)}
            className="px-4 py-2 glass rounded-xl hover:bg-white/10 transition-colors flex items-center gap-2 text-sm font-medium"
          >
            <Upload size={18} />
            Excel Upload
          </button>
          <button 
            onClick={() => setIsAddModalOpen(true)}
            className="px-6 py-2 premium-gradient rounded-xl shadow-lg shadow-emerald-500/20 hover:opacity-90 transition-opacity flex items-center gap-2 text-sm font-bold"
          >
            <Plus size={18} />
            Add Contact
          </button>
        </div>
      </div>

      <div className="glass-card overflow-hidden !p-0">
        <div className="p-4 border-b border-white/10 flex gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
            <input 
              type="text" 
              placeholder="Search contacts..." 
              className="w-full bg-white/5 border border-white/10 rounded-xl py-2 pl-10 pr-4 outline-none focus:border-emerald-500/50 transition-colors"
            />
          </div>
          <select className="bg-white/5 border border-white/10 rounded-xl px-4 outline-none">
            <option>All Batches</option>
            {batches.map((b: any) => <option key={b.id} value={b.id}>{b.name}</option>)}
          </select>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left min-w-[600px]">
            <thead className="bg-white/5 text-zinc-400 text-xs uppercase font-bold">
              <tr>
                <th className="px-6 py-4">Name</th>
                <th className="px-6 py-4">Phone</th>
                <th className="px-6 py-4">Batch</th>
                <th className="px-6 py-4">Tag</th>
                <th className="px-6 py-4">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {contacts.map((contact: any) => (
                <tr key={contact.id} className="hover:bg-white/5 transition-colors group">
                  <td className="px-6 py-4 font-medium">{contact.name}</td>
                  <td className="px-6 py-4 text-zinc-400">{contact.phone}</td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 rounded-lg bg-blue-500/10 text-blue-400 text-xs font-bold">
                      {contact.batch_name || 'Unassigned'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 rounded-lg bg-zinc-500/10 text-zinc-400 text-xs font-bold">
                      {contact.tag || 'None'}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <button className="text-zinc-500 hover:text-white transition-colors">
                      <ChevronRight size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modals */}
      <Modal isOpen={isAddModalOpen} onClose={() => setIsAddModalOpen(false)} title="Add New Contact">
        <form onSubmit={handleAddContact} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-zinc-400">Full Name</label>
              <input 
                required
                value={newContact.name}
                onChange={e => setNewContact({...newContact, name: e.target.value})}
                className="w-full bg-white/5 border border-white/10 rounded-xl p-3 outline-none focus:border-emerald-500/50" 
                placeholder="John Doe"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-zinc-400">Phone Number</label>
              <input 
                required
                value={newContact.phone}
                onChange={e => setNewContact({...newContact, phone: e.target.value})}
                className="w-full bg-white/5 border border-white/10 rounded-xl p-3 outline-none focus:border-emerald-500/50" 
                placeholder="+91 0000000000"
              />
            </div>
          </div>
          <div className="space-y-2">
            <label className="text-sm font-medium text-zinc-400">Batch</label>
            <select 
              value={newContact.batch_id}
              onChange={e => setNewContact({...newContact, batch_id: e.target.value})}
              className="w-full bg-white/5 border border-white/10 rounded-xl p-3 outline-none"
            >
              <option value="">Select Batch</option>
              {batches.map((b: any) => <option key={b.id} value={b.id}>{b.name}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-zinc-400">Tag</label>
              <input 
                value={newContact.tag}
                onChange={e => setNewContact({...newContact, tag: e.target.value})}
                className="w-full bg-white/5 border border-white/10 rounded-xl p-3 outline-none" 
                placeholder="e.g. VIP"
              />
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-zinc-400">Category</label>
              <input 
                value={newContact.category}
                onChange={e => setNewContact({...newContact, category: e.target.value})}
                className="w-full bg-white/5 border border-white/10 rounded-xl p-3 outline-none" 
                placeholder="e.g. Student"
              />
            </div>
          </div>
          <button type="submit" className="w-full py-4 premium-gradient rounded-xl font-bold mt-4 shadow-lg shadow-emerald-500/20">
            Save Contact
          </button>
        </form>
      </Modal>

      <Modal isOpen={isExcelModalOpen} onClose={() => setIsExcelModalOpen(false)} title="Import from Excel">
        <div className="space-y-6 text-center">
          <div className="p-8 border-2 border-dashed border-white/10 rounded-2xl bg-white/5 flex flex-col items-center gap-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/10 text-emerald-500 flex items-center justify-center">
              <FileText size={32} />
            </div>
            <div>
              <p className="font-bold text-lg">Drop your Excel file here</p>
              <p className="text-sm text-zinc-500">Supports .xlsx, .xls, .csv</p>
            </div>
            <input 
              type="file" 
              accept=".xlsx, .xls, .csv" 
              onChange={handleFileUpload}
              className="hidden" 
              id="excel-upload" 
            />
            <label 
              htmlFor="excel-upload"
              className="px-6 py-2 bg-white text-black rounded-xl font-bold cursor-pointer hover:bg-zinc-200 transition-colors"
            >
              Select File
            </label>
          </div>
          <div className="text-left space-y-2">
            <p className="text-xs font-bold text-zinc-500 uppercase">Format Requirements:</p>
            <ul className="text-xs text-zinc-400 space-y-1 list-disc pl-4">
              <li>First row must contain headers: Name, Phone</li>
              <li>Phone numbers should include country code (e.g. 91)</li>
              <li>Duplicates will be automatically merged</li>
            </ul>
          </div>
        </div>
      </Modal>
    </div>
  );
};

const MessagingView = ({ showToast }: any) => {
  const [message, setMessage] = useState('');
  const [isEnhancing, setIsEnhancing] = useState(false);
  const [campaignName, setCampaignName] = useState('');
  const [selectedBatch, setSelectedBatch] = useState('');
  const [batches, setBatches] = useState([]);
  const [mediaFile, setMediaFile] = useState<any>(null);
  const [isGenerating, setIsGenerating] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/batches').then(res => res.json()).then(setBatches);
  }, []);

  const handleAIEnhance = async () => {
    if (!message) return;
    setIsEnhancing(true);
    try {
      await new Promise(r => setTimeout(r, 1500));
      setMessage(prev => `🌟 Hello! ${prev} ✨\n\nSent via TrioBulk AI 🚀`);
      showToast("Message enhanced by AI!");
    } catch (e) {
      showToast("AI Enhancement failed", "error");
    } finally {
      setIsEnhancing(false);
    }
  };

  const handleAICreative = async (type: string) => {
    setIsGenerating(type);
    try {
      await new Promise(r => setTimeout(r, 2000));
      if (type === 'poster') {
        showToast("AI Poster generated and attached!");
        setMediaFile({ name: 'ai-poster.png', type: 'image/png', preview: 'https://picsum.photos/seed/poster/800/1000' });
      } else {
        showToast("AI Ad Copy generated!");
        setMessage("🚀 BOOST YOUR BUSINESS WITH TRIOBULK!\n\nJoin the elite group of marketers using AI to scale their WhatsApp outreach. High conversion, zero hassle.\n\n👉 Get started today!");
      }
    } finally {
      setIsGenerating(null);
    }
  };

  const handleLaunch = async () => {
    if (!campaignName || !message || !selectedBatch) {
      showToast("Please fill all fields", "error");
      return;
    }

    const res = await fetch('/api/campaigns', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        name: campaignName,
        content: message,
        type: 'bulk',
        batch_id: selectedBatch,
        media_url: mediaFile?.preview || null
      })
    });

    if (res.ok) {
      showToast("Campaign launched successfully!");
      setCampaignName('');
      setMessage('');
      setSelectedBatch('');
      setMediaFile(null);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
      <div className="lg:col-span-2 space-y-6">
        <div className="glass-card space-y-6">
          <div className="space-y-2">
            <label className="text-sm font-medium text-zinc-400">Campaign Name</label>
            <input 
              value={campaignName}
              onChange={e => setCampaignName(e.target.value)}
              placeholder="e.g. Morning Batch Welcome"
              className="w-full bg-white/5 border border-white/10 rounded-xl p-3 outline-none focus:border-emerald-500/50"
            />
          </div>
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <label className="text-sm font-medium text-zinc-400">Message Content</label>
              <div className="flex gap-2">
                {['{{name}}', '{{batch}}', '{{time}}'].map(tag => (
                  <button 
                    key={tag}
                    onClick={() => setMessage(prev => prev + tag)}
                    className="px-2 py-1 bg-white/5 border border-white/10 rounded-lg text-[10px] font-mono hover:bg-white/10 transition-colors"
                  >
                    {tag}
                  </button>
                ))}
              </div>
            </div>
            <textarea 
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Type your message here..."
              className="w-full h-48 bg-white/5 border border-white/10 rounded-2xl p-4 outline-none focus:border-emerald-500/50 transition-colors resize-none"
            />
            
            {/* Media Upload Section */}
            <div className="flex gap-4">
              <input 
                type="file" 
                id="media-upload" 
                className="hidden" 
                accept="image/*,video/*"
                onChange={(e: any) => {
                  const file = e.target.files[0];
                  if (file) {
                    setMediaFile({
                      name: file.name,
                      type: file.type,
                      preview: URL.createObjectURL(file)
                    });
                  }
                }}
              />
              <label 
                htmlFor="media-upload"
                className="flex-1 p-4 border-2 border-dashed border-white/10 rounded-2xl bg-white/5 hover:bg-white/10 transition-all cursor-pointer flex items-center justify-center gap-3 group"
              >
                {mediaFile ? (
                  <div className="flex items-center gap-3 text-emerald-400">
                    {mediaFile.type.startsWith('image') ? <ImageIcon size={20} /> : <Video size={20} />}
                    <span className="text-sm font-medium truncate max-w-[200px]">{mediaFile.name}</span>
                    <button onClick={(e) => { e.preventDefault(); setMediaFile(null); }} className="p-1 hover:bg-white/10 rounded">
                      <X size={14} />
                    </button>
                  </div>
                ) : (
                  <>
                    <div className="flex gap-2 text-zinc-500 group-hover:text-white transition-colors">
                      <ImageIcon size={20} />
                      <Video size={20} />
                    </div>
                    <span className="text-sm font-medium text-zinc-500 group-hover:text-white transition-colors">Attach Image or Video</span>
                  </>
                )}
              </label>
            </div>

            <div className="flex justify-between items-center">
              <button 
                onClick={handleAIEnhance}
                disabled={isEnhancing || !message}
                className="flex items-center gap-2 text-emerald-400 hover:text-emerald-300 transition-colors text-sm font-bold disabled:opacity-50"
              >
                <Sparkles size={18} className={isEnhancing ? "animate-pulse" : ""} />
                {isEnhancing ? "Enhancing..." : "AI Enhance Message"}
              </button>
              <span className="text-xs text-zinc-500">{message.length} characters</span>
            </div>
          </div>
        </div>

        <div className="glass-card">
          <h3 className="text-xl font-bold mb-6">Campaign Settings</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-zinc-400">Select Batch</label>
              <select 
                value={selectedBatch}
                onChange={e => setSelectedBatch(e.target.value)}
                className="w-full bg-white/5 border border-white/10 rounded-xl p-3 outline-none"
              >
                <option value="">Choose a batch...</option>
                {batches.map((b: any) => <option key={b.id} value={b.id}>{b.name}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-sm font-medium text-zinc-400">Schedule Time (Optional)</label>
              <input type="datetime-local" className="w-full bg-white/5 border border-white/10 rounded-xl p-3 outline-none" />
            </div>
          </div>
          <button 
            onClick={handleLaunch}
            className="w-full mt-8 py-4 premium-gradient rounded-2xl shadow-xl shadow-emerald-500/20 text-lg font-bold hover:opacity-90 transition-all active:scale-[0.98]"
          >
            Launch Campaign
          </button>
        </div>
      </div>

      <div className="space-y-6">
        <div className="glass-card">
          <h3 className="text-lg font-bold mb-4">Message Preview</h3>
          <div className="bg-[#0b141a] rounded-2xl p-4 min-h-[250px] relative overflow-hidden flex flex-col gap-2">
            <div className="absolute top-0 left-0 w-full h-1 bg-emerald-500" />
            
            {mediaFile && (
              <div className="w-full aspect-video rounded-lg overflow-hidden bg-black/20">
                {mediaFile.type.startsWith('image') ? (
                  <img src={mediaFile.preview} className="w-full h-full object-cover" alt="Preview" />
                ) : (
                  <div className="w-full h-full flex items-center justify-center text-zinc-500">
                    <Video size={32} />
                  </div>
                )}
              </div>
            )}

            <div className="bg-[#202c33] rounded-lg p-3 text-sm text-zinc-200 max-w-[85%] shadow-sm self-start">
              {message || "Your message preview will appear here..."}
              <div className="text-[10px] text-zinc-500 text-right mt-1">10:45 AM</div>
            </div>
          </div>
        </div>

        <div className="glass-card">
          <h3 className="text-lg font-bold mb-4">AI Creative Tools</h3>
          <div className="space-y-3">
            <button 
              onClick={() => handleAICreative('poster')}
              disabled={!!isGenerating}
              className="w-full p-3 glass rounded-xl text-left hover:bg-white/10 transition-all flex items-center gap-3 disabled:opacity-50"
            >
              <div className="p-2 rounded-lg bg-emerald-500/20 text-emerald-400">
                <Sparkles size={16} className={isGenerating === 'poster' ? "animate-spin" : ""} />
              </div>
              <span className="text-sm font-medium">{isGenerating === 'poster' ? "Generating..." : "Generate Poster"}</span>
            </button>
            <button 
              onClick={() => handleAICreative('adcopy')}
              disabled={!!isGenerating}
              className="w-full p-3 glass rounded-xl text-left hover:bg-white/10 transition-all flex items-center gap-3 disabled:opacity-50"
            >
              <div className="p-2 rounded-lg bg-blue-500/20 text-blue-400">
                <Sparkles size={16} className={isGenerating === 'adcopy' ? "animate-spin" : ""} />
              </div>
              <span className="text-sm font-medium">{isGenerating === 'adcopy' ? "Generating..." : "AI Ad Copy"}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

const PaymentsView = ({ showToast }: any) => {
  const [isPaymentModalOpen, setIsPaymentModalOpen] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [transactionId, setTransactionId] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);

  const handlePaymentSubmit = async (e: any) => {
    e.preventDefault();
    setIsVerifying(true);
    const res = await fetch('/api/payments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        plan_name: selectedPlan.name,
        amount: selectedPlan.price,
        transaction_id: transactionId,
        payment_method: 'UPI'
      })
    });

    if (res.ok) {
      showToast("Payment submitted for verification!");
      setIsPaymentModalOpen(false);
      setTransactionId('');
    }
    setIsVerifying(false);
  };

  return (
    <div className="space-y-8">
      <div className="text-center max-w-2xl mx-auto space-y-4">
        <h2 className="text-4xl font-extrabold premium-text-gradient">Choose Your Plan</h2>
        <p className="text-zinc-400">Scale your WhatsApp marketing with our premium AI-powered plans.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {[
          { name: "Free Trial", price: "0", features: ["7 Days Access", "100 Messages", "Basic AI Tools"], color: "border-white/10" },
          { name: "Monthly Premium", price: "1799", features: ["Unlimited Messages", "Advanced AI Suite", "Priority Support", "Custom Branding"], color: "border-emerald-500/50 bg-emerald-500/5", popular: true },
          { name: "Yearly Pro", price: "11999", features: ["Everything in Monthly", "2 Months Free", "Dedicated Account Manager", "API Access"], color: "border-white/10" },
        ].map((plan, i) => (
          <div key={i} className={cn("glass-card relative flex flex-col", plan.color)}>
            {plan.popular && (
              <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-1 bg-emerald-500 text-[10px] font-bold uppercase tracking-widest rounded-full">
                Most Popular
              </div>
            )}
            <div className="mb-8">
              <h4 className="text-xl font-bold mb-2">{plan.name}</h4>
              <div className="flex items-baseline gap-1">
                <span className="text-4xl font-black">₹{plan.price}</span>
                <span className="text-zinc-500 text-sm">/period</span>
              </div>
            </div>
            <ul className="space-y-4 mb-8 flex-1">
              {plan.features.map((f, j) => (
                <li key={j} className="flex items-center gap-3 text-sm text-zinc-300">
                  <CheckCircle2 size={16} className="text-emerald-500" />
                  {f}
                </li>
              ))}
            </ul>
            <button 
              onClick={() => {
                setSelectedPlan(plan);
                setIsPaymentModalOpen(true);
              }}
              className={cn(
                "w-full py-4 rounded-xl font-bold transition-all",
                plan.popular ? "premium-gradient shadow-lg shadow-emerald-500/20" : "glass hover:bg-white/10"
              )}
            >
              Get Started
            </button>
          </div>
        ))}
      </div>

      <Modal isOpen={isPaymentModalOpen} onClose={() => setIsPaymentModalOpen(false)} title={`Upgrade to ${selectedPlan?.name}`}>
        <div className="space-y-6">
          <div className="flex flex-col items-center gap-4 p-6 bg-white rounded-2xl">
            <QRCodeSVG 
              value={`upi://pay?pa=9551522030-3@ibl&pn=Trio%20Developers&am=${selectedPlan?.price}&cu=INR`} 
              size={200}
              level="H"
              includeMargin={true}
            />
            <div className="text-center">
              <p className="text-black font-bold">Scan to Pay ₹{selectedPlan?.price}</p>
              <p className="text-zinc-500 text-xs">Trio Developers (9551522030-3@ibl)</p>
            </div>
          </div>

          <form onSubmit={handlePaymentSubmit} className="space-y-4">
            <div className="space-y-2">
              <label className="text-sm font-medium text-zinc-400">Transaction ID / UTR Number</label>
              <input 
                required
                value={transactionId}
                onChange={e => setTransactionId(e.target.value)}
                placeholder="Enter 12-digit UTR number"
                className="w-full bg-white/5 border border-white/10 rounded-xl p-3 outline-none focus:border-emerald-500/50"
              />
            </div>
            <button 
              type="submit" 
              disabled={isVerifying}
              className="w-full py-4 premium-gradient rounded-xl font-bold disabled:opacity-50"
            >
              {isVerifying ? "Verifying..." : "Confirm Payment"}
            </button>
          </form>
        </div>
      </Modal>

      <div className="glass-card max-w-xl mx-auto text-center space-y-6">
        <h3 className="text-xl font-bold">Manual Payment Details</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="p-4 bg-white/5 rounded-xl border border-white/10">
            <p className="text-xs text-zinc-500 uppercase font-bold mb-1">UPI ID</p>
            <p className="font-mono text-sm">9551522030-3@ibl</p>
          </div>
          <div className="p-4 bg-white/5 rounded-xl border border-white/10">
            <p className="text-xs text-zinc-500 uppercase font-bold mb-1">Phone</p>
            <p className="font-mono text-sm">+91 9551522030</p>
          </div>
        </div>
      </div>
    </div>
  );
};

const SettingsView = ({ showToast }: any) => {
  const [settings, setSettings] = useState({
    whatsapp_api_key: '',
    whatsapp_phone_id: '',
    whatsapp_business_id: ''
  });
  const [isSaving, setIsSaving] = useState(false);

  useEffect(() => {
    fetch('/api/settings').then(res => res.json()).then(setSettings);
  }, []);

  const handleSave = async (e: any) => {
    e.preventDefault();
    setIsSaving(true);
    const res = await fetch('/api/settings', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings)
    });
    if (res.ok) {
      showToast("Settings saved successfully!");
    }
    setIsSaving(false);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Settings</h2>
          <p className="text-zinc-400">Configure your WhatsApp API and platform preferences</p>
        </div>
        <button 
          onClick={handleSave}
          disabled={isSaving}
          className="px-6 py-2 premium-gradient rounded-xl font-bold shadow-lg shadow-emerald-500/20 disabled:opacity-50"
        >
          {isSaving ? "Saving..." : "Save Changes"}
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="md:col-span-2 space-y-6">
          <div className="glass-card space-y-6">
            <div className="flex items-center gap-3 text-emerald-400">
              <Shield size={20} />
              <h3 className="text-lg font-bold text-white">WhatsApp API Configuration</h3>
            </div>
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium text-zinc-400">Meta API Key</label>
                <div className="relative">
                  <Key className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
                  <input 
                    type="password"
                    value={settings.whatsapp_api_key}
                    onChange={e => setSettings({...settings, whatsapp_api_key: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl py-3 pl-10 pr-4 outline-none focus:border-emerald-500/50" 
                    placeholder="Enter your Meta API Key"
                  />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-400">Phone Number ID</label>
                  <input 
                    value={settings.whatsapp_phone_id}
                    onChange={e => setSettings({...settings, whatsapp_phone_id: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl p-3 outline-none focus:border-emerald-500/50" 
                    placeholder="e.g. 1029384756"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium text-zinc-400">Business Account ID</label>
                  <input 
                    value={settings.whatsapp_business_id}
                    onChange={e => setSettings({...settings, whatsapp_business_id: e.target.value})}
                    className="w-full bg-white/5 border border-white/10 rounded-xl p-3 outline-none focus:border-emerald-500/50" 
                    placeholder="e.g. 5647382910"
                  />
                </div>
              </div>
            </div>
          </div>

          <div className="glass-card space-y-6">
            <div className="flex items-center gap-3 text-blue-400">
              <Palette size={20} />
              <h3 className="text-lg font-bold text-white">Branding & Theme</h3>
            </div>
            <div className="space-y-4">
              <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/10">
                <div>
                  <p className="font-bold">Dark Mode</p>
                  <p className="text-xs text-zinc-500">Always active for premium feel</p>
                </div>
                <div className="w-12 h-6 bg-emerald-500 rounded-full relative">
                  <div className="absolute right-1 top-1 w-4 h-4 bg-white rounded-full" />
                </div>
              </div>
              <div className="flex items-center justify-between p-4 bg-white/5 rounded-xl border border-white/10">
                <div>
                  <p className="font-bold">Show Watermark</p>
                  <p className="text-xs text-zinc-500">Display "Trio Developers" on exports</p>
                </div>
                <div className="w-12 h-6 bg-zinc-700 rounded-full relative">
                  <div className="absolute left-1 top-1 w-4 h-4 bg-white rounded-full" />
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="glass-card bg-emerald-500/5 border-emerald-500/20">
            <div className="flex items-center gap-3 text-emerald-400 mb-4">
              <Crown size={20} />
              <h3 className="text-lg font-bold">Subscription</h3>
            </div>
            <div className="space-y-4">
              <div className="p-3 bg-white/5 rounded-xl">
                <p className="text-xs text-zinc-500 uppercase font-bold">Current Plan</p>
                <p className="text-lg font-bold">7-Day Free Trial</p>
              </div>
              <div className="space-y-1">
                <div className="flex justify-between text-xs font-bold">
                  <span className="text-zinc-500">TRIAL PROGRESS</span>
                  <span className="text-emerald-400">2 / 7 DAYS</span>
                </div>
                <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden">
                  <div className="w-[28%] h-full bg-emerald-500" />
                </div>
              </div>
              <button 
                onClick={() => (window as any).setActiveTab('payments')}
                className="w-full py-3 premium-gradient rounded-xl font-bold shadow-lg shadow-emerald-500/20"
              >
                Upgrade to Pro
              </button>
            </div>
          </div>

          <div className="glass-card">
            <h3 className="text-lg font-bold mb-4">Quick Links</h3>
            <div className="space-y-2">
              <button className="w-full p-3 hover:bg-white/5 rounded-xl text-left text-sm flex items-center gap-3 transition-colors">
                <Globe size={16} className="text-zinc-500" />
                API Documentation
              </button>
              <button className="w-full p-3 hover:bg-white/5 rounded-xl text-left text-sm flex items-center gap-3 transition-colors">
                <Shield size={16} className="text-zinc-500" />
                Privacy Policy
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

// --- Main App ---

export default function App() {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [stats, setStats] = useState<any>(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [toast, setToast] = useState<any>(null);
  const [notifications, setNotifications] = useState<any[]>([]);
  const [isNotifOpen, setIsNotifOpen] = useState(false);

  // Expose setActiveTab to window for the SettingsView upgrade button
  useEffect(() => {
    (window as any).setActiveTab = setActiveTab;
  }, []);

  const showToast = (message: string, type: string = 'success') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3000);
  };

  useEffect(() => {
    fetch('/api/stats').then(res => res.json()).then(setStats);
    fetch('/api/notifications').then(res => res.json()).then(setNotifications);
  }, []);

  const menuItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'contacts', label: 'Contacts', icon: Users },
    { id: 'messaging', label: 'Messaging', icon: Send },
    { id: 'history', label: 'History', icon: History },
    { id: 'payments', label: 'Payments', icon: CreditCard },
    { id: 'settings', label: 'Settings', icon: Settings },
  ];

  return (
    <div className="min-h-screen flex bg-[#050505]">
      <AnimatePresence>
        {toast && <Toast {...toast} onClose={() => setToast(null)} />}
      </AnimatePresence>

      {/* Sidebar */}
      <motion.aside 
        initial={false}
        animate={{ width: isSidebarOpen ? 280 : 80 }}
        className="fixed left-0 top-0 h-full glass border-r border-white/5 z-50 flex flex-col"
      >
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 premium-gradient rounded-xl flex items-center justify-center shadow-lg shadow-emerald-500/20">
            <Zap className="text-white" size={24} />
          </div>
          {isSidebarOpen && (
            <motion.span 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="font-black text-xl tracking-tighter"
            >
              TRIO<span className="text-emerald-500">PRO</span>
            </motion.span>
          )}
        </div>

        <nav className="flex-1 px-4 py-6 space-y-2">
          {menuItems.map((item) => (
            <SidebarItem 
              key={item.id}
              {...item}
              active={activeTab === item.id}
              onClick={() => setActiveTab(item.id)}
            />
          ))}
        </nav>

        {isSidebarOpen && (
          <div className="px-6 py-4 mx-4 mb-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl">
            <p className="text-[10px] font-bold text-emerald-500 uppercase tracking-widest mb-1">Free Trial</p>
            <p className="text-sm font-bold">5 Days Remaining</p>
            <button 
              onClick={() => setActiveTab('payments')}
              className="mt-3 w-full py-2 bg-emerald-500 text-white text-xs font-bold rounded-lg hover:opacity-90 transition-opacity"
            >
              Upgrade Now
            </button>
          </div>
        )}

        <div className="p-4 border-t border-white/5">
          <button 
            onClick={() => window.location.reload()}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-zinc-400 hover:bg-red-500/10 hover:text-red-400 transition-all"
          >
            <LogOut size={20} />
            {isSidebarOpen && <span className="font-medium">Logout</span>}
          </button>
        </div>
      </motion.aside>

      {/* Main Content */}
      <main className={cn(
        "flex-1 transition-all duration-300",
        isSidebarOpen ? "ml-[280px]" : "ml-[80px]"
      )}>
        {/* Header */}
        <header className="h-20 glass border-b border-white/5 flex items-center justify-between px-8 sticky top-0 z-40">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="p-2 hover:bg-white/5 rounded-lg transition-colors"
            >
              <Menu size={20} />
            </button>
            <div className="h-6 w-px bg-white/10" />
            <h1 className="text-lg font-bold capitalize">{activeTab}</h1>
          </div>

          <div className="flex items-center gap-6">
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" size={18} />
              <input 
                type="text" 
                placeholder="Search anything..." 
                className="bg-white/5 border border-white/10 rounded-xl py-2 pl-10 pr-4 w-64 outline-none focus:border-emerald-500/50 transition-colors"
              />
            </div>
            <div className="relative">
              <button 
                onClick={() => setIsNotifOpen(!isNotifOpen)}
                className="relative p-2 hover:bg-white/5 rounded-lg transition-colors"
              >
                <Bell size={20} />
                {notifications.some(n => !n.read) && (
                  <span className="absolute top-2 right-2 w-2 h-2 bg-emerald-500 rounded-full border-2 border-[#050505]" />
                )}
              </button>

              <AnimatePresence>
                {isNotifOpen && (
                  <>
                    <div className="fixed inset-0 z-40" onClick={() => setIsNotifOpen(false)} />
                    <motion.div 
                      initial={{ opacity: 0, y: 10, scale: 0.95 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      exit={{ opacity: 0, y: 10, scale: 0.95 }}
                      className="absolute right-0 mt-4 w-80 glass-card !p-0 z-50 shadow-2xl border-white/20"
                    >
                      <div className="p-4 border-b border-white/10 flex justify-between items-center">
                        <h4 className="font-bold">Notifications</h4>
                        <button className="text-xs text-emerald-500 font-bold">Mark all read</button>
                      </div>
                      <div className="max-h-96 overflow-y-auto">
                        {notifications.map((n) => (
                          <div key={n.id} className={cn("p-4 border-b border-white/5 hover:bg-white/5 transition-colors cursor-pointer", !n.read && "bg-emerald-500/5")}>
                            <p className="text-sm font-bold">{n.title}</p>
                            <p className="text-xs text-zinc-400 mt-1">{n.message}</p>
                            <p className="text-[10px] text-zinc-500 mt-2">{n.time}</p>
                          </div>
                        ))}
                      </div>
                      <div className="p-3 text-center">
                        <button className="text-xs text-zinc-500 hover:text-white transition-colors">View all history</button>
                      </div>
                    </motion.div>
                  </>
                )}
              </AnimatePresence>
            </div>
            <div className="flex items-center gap-3 pl-6 border-l border-white/10">
              <div className="text-right hidden sm:block">
                <p className="text-sm font-bold">Trio Admin</p>
                <p className="text-[10px] text-emerald-500 font-bold uppercase tracking-wider">Premium Plan</p>
              </div>
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-zinc-700 to-zinc-900 border border-white/10" />
            </div>
          </div>
        </header>

        {/* Content Area */}
        <div className="p-8 max-w-7xl mx-auto">
          <AnimatePresence mode="wait">
            <motion.div
              key={activeTab}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.2 }}
            >
              {activeTab === 'dashboard' && <DashboardView stats={stats} />}
              {activeTab === 'contacts' && <ContactsView showToast={showToast} />}
              {activeTab === 'messaging' && <MessagingView showToast={showToast} />}
              {activeTab === 'payments' && <PaymentsView showToast={showToast} />}
              {activeTab === 'settings' && <SettingsView showToast={showToast} />}
              {['history'].includes(activeTab) && (
                <div className="glass-card flex flex-col items-center justify-center py-20 text-center space-y-4">
                  <div className="w-16 h-16 rounded-full bg-white/5 flex items-center justify-center text-zinc-500">
                    <Clock size={32} />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold">Coming Soon</h3>
                    <p className="text-zinc-400">This module is currently under development.</p>
                  </div>
                </div>
              )}
            </motion.div>
          </AnimatePresence>
        </div>

        {/* Branding Watermark */}
        <div className="fixed bottom-6 right-8 opacity-20 pointer-events-none select-none">
          <p className="text-xs font-black tracking-widest uppercase">Trio Developers</p>
        </div>
      </main>
    </div>
  );
}
